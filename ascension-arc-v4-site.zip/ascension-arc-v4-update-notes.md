# Ascension Arc V4 Update Notes

## What changed

- Added collapsible Codex sections using dropdown boxes.
- Added per-profile themes:
  - Nightmare Ascension
  - Heavenly Blessing
  - Arcane Scholar
- Preserved the same ascension ladder: Sleeper, Awakened, Ascended, Transcendent, Supreme, Sacred, Divine.
- Added tab transition animations between Home, Quests, Boss, Review, and Codex.
- Added theme support to questionnaire starter links so your girlfriend can receive the same quest/stat template and selected visual theme.
- Kept the static link system: questionnaire starter links and full profile snapshot links.

## How to update Netlify

1. Rename the updated HTML file to `index.html`, or use the included `ascension-arc-v4-site` folder.
2. Open your existing Netlify site dashboard.
3. Go to Deploys.
4. Drag the updated folder into the deploy dropzone for the existing site, not the general Netlify Drop page.
5. Keep using the same public Netlify URL.

## Important

If you generate a new questionnaire starter link after updating, it will include the new theme settings. Old links should still open, but they will not include newer customizations that were added after the old link was created.
